include<opencv2/highgui/highgui.hpp>
include<opencv2/imgproc/imgproc.hpp>
include<pcl/point_types.h>
#include <pcl/features/normal_3d.h>
#include < pcl/filters/voxel_grid.h>
#include <ctime>
#include <rclcpp/rclcpp.hpp>
#include < sensor_msgs/msg/image.hpp>
#include "std_msgs/ msg/float32_multi_array.hpp"
#include <iostream>
#include <vector>
#include <math.h>
#include <limits>

#define color_width 1280
#define color_height 720

#define depth_width 1280
#define depth_height 720

using pcl_ptr = pcl::PointCloud<pcl::PointXYZ>::Ptr;
class plane_node: public rclcpp::Node {
using ImageMsg = sensor_msgs::msg::Image;
public :
plane_node() : Node("plane_fitness_node"){
	initialize();
	auto plane_callback = 
	[this] (const ImageMsg::SharedPtr msg) {
		auto start = std::chrono::high_resolution_clock::now();
		//std::cout<< "input image" << msg->width<< "," << msg->height << "," << msg->step << std::endl;
		depth_mat.data = (uchar*) reinterpret_cast<uint16_t *> (msg->data.data());
		convert(depth_mat, cloud);
		grid.setInputCloud(cloud);
		grid.filter ( *cloud_filter);
		ne.setInputCloud( cloud_filter);
		ne.setSearchSurface ( cloud);
		ne.compute( *cloud_normals);
		std::vector<int> point_indics_temp;
		for (uint32_t i =0; i<cloud_normals->points.size(); i++) {
		n_x = (cloud_normals->points[i]).normal_x;
		n_y = (cloud_normals-> points[i].normal_y;
		n_z = (cloud_normals->points[i].normal_z;
		y= cloud_filter->points[i].y;
		if (filter_points (n_x, n_y, n_z, 0, -1, 0, 5) && y>0.54 &&y<0.59){
			point_indics_temp.push_back(i);
		}
		}//end for i
		rows = point_indics_temp.size();
		if( rows<100) {
			std::cout << "rows:" << rows<< std::endl;
		}
		cv::Mat mat (rows, 4, CV_32FC1) , matD, matU, matVt; 
		for int( i=0; i<rows; i++){
			mat.at<float>(i,0) = (cloud_filter->points[point_indics_temp[i]]).x;
			mat.at<float>(i,1) = (cloud_filter->points[point_indics_temp[i]]).y;
			mat.at<float>(i,2) = (cloud_filter->points[point_indics_temp[i]]).z;
			mat.at<float>(i,3) = 1;
		}
		cv::SVD::compute(mat, matD, matU, matVT, 4);
		vecCoefficients.data[0] = matVt.at<float>(3,0);
		vecCoefficients.data[1] = matVt.at<float>(3,1);
		vecCoefficients.data[2] = matVt.at<float>(3,2);
		vecCoefficients.data[3] = matVt.at<float>(3,3);
		vecCoefficients.data[4] = rows;

		std::cout<< "a=" << vecCoefficients.data[0] << "b=" << [1] << "c=" << [2] << "d=" << [3] << std::endl;
		this-> publisher_ -> publish(vecCoefficients);
		std::this_thread::sleep_for( std::chrono::milliseconds(1));
	}; //end auto plane_callback

	subscription_ = this->create_subscription<ImageMsg>{"/camera/depth/image_depth", plane_callback);
	publisher_ = this->create_publisher<std::msgs::msg::Float32MultiArray("floor_coefficient");
}// end plane_node()

private:
inline_bool filter_points{float x1, float y1, float z1, float x2, float y2, float z2, float threshold1){
	if(std::isnan(x1)|| std::isnan(y1)|| std::isnan(z1))
	return false;
	float deg = acos( -y1/(sqrt( x1*x1 + y1*y1 +z1*z1 ))) * 180/3.141592654;
	if (deg < threshold1) return true;
	else return false;
}//end inline

private: 
pcl_ptr cloud;
pcl::VoxelGrid<pcl::PointXYZ> grid;
pcl::NormalEstimation< pcl::PointXYZ, pcl::Normal> ne;
pcl::search::KdTree <pcl::PointXYZ> :: Ptr tree;
pcl::PointCloud <pcl::Normal> :: Ptr cloud_normals;
pcl_ptr cloud_filter;

cv::Mat depth_mat = cv::Mat( depth_height, depth_width, CV_16UC1);
cv::Mat color_mat = cv::Mat(color_height, color_width, CV8UC3);

rclcpp::Subscription<ImageMsg>::SharedPtr subscription_;
rclcpp::Publisher<std_msgs::msg::Float32MultiArray>::SharedPtr publisher_;
std::msgs::msg::Float32MultiArray vecCoefficients;
float bad_point = std::numeric_limits<float>::quiet_NaN();
float n_x, n_y, n_z, x, y, z; //x, z useless
int rows = 0;

private:
void initialize(){
	cloud.reset(new pcl::PointCloud<pcl::PointXYZ>);
	cloud_normals.reset( new pcl::PointCloud<pcl::Normal>);
	cloud_filter.reset(new pcl::PointCloud<pcl::PointXYZ>);
	tree.reset ( new pcl::search::KdTree<pcl::PointXYZ>());
	ne.setSearchMethod(tree);
	ne.setRadiusSearch(0.05);
	grid.setLeafSize(0.1f, 0.1f, 0.1f);
	cloud->width = depth_width;
	cloud->height = depth_height;
	cloud-> is_dense = false;
	cloud->points.resize(depth_width * depth_height);
	//cv::namedWindow("Color", CV_WINDOW_KEEPRATIO);
	vecCoefficients.data.resize(5);
	std::cout <<"initialize finished" << std::endl;
}

private :
inline bool valid(uint16_t depth) {return depth!= 0; }

void convert ( const cv::Mat & depth_mat, const pcl_ptr& cloud){
pcl::PointCloud<pcl::PointXYZ> :: iterator iter = (*cloud).begin();
	for (int m=0; m<depth_mat.rows; m++){
		for( int n=0; n<depth_mat.cols; n++){
		uint16_t d= depth_mat.ptr<uint16_t>(m)[n];
			if( !valid(d)) {
			iter->z = iter->x = iter->y = bad_point;
			}
			else{
			iter->z = double(d) * 0.0010000000474974513;
			iter->x =(n-642.882935) * iter->z / 922.820068;
			iter->y = (m-374.07019) * iter->z / 922.734558 //these are camera internal parameters
			iter++;
			}
		}	
	}// end for m
}; //end void convert

int main( int argc, char* argv[]) 
{
	rclcpp:: init( argc, argv);
	auto node = std::make_shared<plane_node>();

	try{
	rclcpp::spin(node);
	}
	catch(std::exceptions& e) {
	RCLCPP_ERROR(node->get_logger(, "Runtime exception: '%s' ", e.what());
	}
	catch(...){
	RCLCPP_ERROR(node->get_logger(), "Unknown runtime exception");
	rclcpp::shutdown();
	return 0;
}


