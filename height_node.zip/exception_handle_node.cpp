#include <unistd.h> //for sleep()
#include<iostream>
#include<memory>

#include<opencv2/highgui/highgui.hpp>
#include "exception_handle_node.hpp"

using ImageMsg = sensor_msgs::msg::Image;
using namespace std;
using std::placeholders::_1;

static int frame_cnt = 0;

Multiple_subscriber_node:: Multiple_subscriber_node() : Node("multiple_subscriber_node")
{
	//initialize
	shared_ptr<Skeleton> sk(new Skeleton());
	cout<< "Skeleton:" << endl;
	sk-> show();

	shared_ptr<Model_processor>model_inst( new Model_processor());
	cout<< "model_inst ppx:" <<( model_inst->intri).ppx << "fx:" << (model_inst->intri).fx <<endl;

	shared_ptr<Msg_processor>msg_inst(new Msg_processor());

	//subscribe
	rgb_sub = std::make_shared<message_filters::Subscriber<ImageMsg> > ( shared_ptr<rclcpp::Node> ( this) , "/camera/color/image_raw");
	depth_sub = std::make_shared<message_filters::Subscriber<ImageMsg> > ( shared_ptr<rclcpp::Node> ( this) , "/camera/depth/image_depth");
	skeleton_sub = std::make_shared<message_filters::Subscriber<std_msgs::msg::Float32MultiArray> > ( shared_ptr<rclcpp::Node> ( this) , "human_pose_result");
	floor_sub = std::make_shared<message_filters::Subscriber<std_msgs::msg::Float32MultiArray> > ( shared_ptr<rclcpp::Node> ( this) , "floor_coefficient");

	syncApproximate = std::make_shared<message_filters::Synchronizer<approximate_sync_policy>> ( approximate_sync_policy(10) , *rgb_sub, *depth_sub, *skeleton_sub, *floor_sub);

	//cv::namedWindow("depth");
	//cv::namedWindow("color");


}//end MultipleSubscriberNode()

Multiple_subscriber_node::~Multiple_subscriber_node(){
	//cv::destroyWindow("color");
	//cv::destroyWindow("depth");
}

void Multiple_subscriber_node::exception_handle( const ImageMsg::SharedPtr msgRGB, const ImageMsg::SharedPtr msgD, 
const std_msgs::msg::Float32MultiArray::SharedPtr msgSKE, const std_msgs::msg::Float32Array::SharedPtr msgFLR)
{
	try{
		cv_ptrRGB = cv_bridge::toCvShare(msgRGB);
	}
	catch ( cv_bridge::Exception & e){
		RCLCPP_ERROR(this->get_logger(), "cv_bridge exception %s", e.what());
		return;
	}

	try{
		cv_ptrD = cv_bridge::toCvShare(msgD);
	}
	catch ( cv_bridge::Exception & e){
		RCLCPP_ERROR(this->get_logger(), "cv_bridge exception %s", e.what());
		return;
	}

	int msg_errorcode1 = msg_inst.parseHumanSkeleton(msgSKE);
	int msg_errorcode2 = msg_inst.parseGroundEstimation(msgFLR);
	//Data processing
	int hm_errorcode = image_show_double();

	double ground[4];
	for (int i=0; i<4; i++){
		ground[i] = static_cast<double>(msg_inst.ground_msg[i]);
	}

	float skeleton_data[17][3];
	for(int i=0;i<17;i++){
		for(int j=0;j<3;j++){
			skeleton_data[i][j] = 0;
		}
	}
	skeleton_data[0][0] = 610;
	skeleton_data[0][1] = 60;
	skeleton_data[0][2] = 1;
	//nose pixel x,y, 1 for detected

	cv:Mat matD = cv_ptrD->image;
	double height =0;

	int hm_errorcode2 = model_inst.proc(height, ground, skeleton_data, matD);
	cout<< "hm_errorcode2:" << hm_errorcode2 << endl;
	//publisher
}//end  exception_handle()

int Multiple_subscriber_node::image_show_double(){
	cv::Mat matRGB = cv_ptrRGB->image;

	cv::Mat matD = cv_ptrD->image;
	cv::Mat tempMatD;
	double tmp_scale = 255.0/4000;
	matD.convertTo( tempMatD, CV_8U, tmp_scale);

	//DEBUG: show elements
	cout<< "RGB Type" << type2str(matRGB.type()) << endl;
	cout <<"matRGB Size: "<< matRGB.rows << "," << matRGB.cols << "," << endl;
	for (int i=0 ; i<10; i++){
		cout << " " << static_cast<int> (matRGB.at<uchar>(0,i,0));
	}
	cout << " " << endl;

	cout<< "matD Type" << type2str(matD.type()) << endl;
	cout <<"matD Size: "<< matD.rows << "," << matD.cols << "," << endl;
	for (int i=0 ; i<10; i++){
		cout << " " << static_cast<int> (matRGB.at<ushort>(100,i));
	}
	cout << " " << endl;

	frame_cnt++;
	if( frame_cnt == 1){
		std::string filename_rgb = "/home/img_cache/color" + std::to_string(frame_cnt) + ".png";
		cv::imwrite(filename_rgb, matRGB);
		std::string filename_d = "/home/img_cache/depth" + std::to_string(frame_cnt) + ".png";
		cv::imwrite(filename_d, tempMatD);
	}	
	sleep(1);
	return 0;
}//end image_show_double()

int main(int argc, char ** argv){
	rclcpp::init(argc, argv);
	auto node = std::make_shared<Multiple_subscriber_node>();

	rclcpp::spin(node);

	rclcpp::shutdown();
}//end main

