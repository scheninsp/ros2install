#ifndef MULTIPLE_SUBCRIBER_NODE
#define MULTIPLE_SUBSCRIBER_NODE

#include <message_filters/subscriber.h>
#include<message_filters/synchronizer.h>
#include<message_filters/sync_policies/approximate_time.h>

#include "rclcpp/rclcpp.hpp"
#include"sensor_msgs/msg/image.hpp"
#include "std_msgs/msg/float32_multi_array.hpp"

#include <cv_bridge/cv_bridge.h>

#include "skeleton_processor.hpp"
#include "model_processor.hpp"
#include "msg_processor..hpp"

typedef message_filters::sync_policies::ApproximateTime<sensor_msgs::msg::Image, sensor_msgs::msg:::Image, std_msgs::msg::Float32MultiArray, std_msgs::msg::Float32MultiArray> approximate_sync_policy;

class Multiple_subscriber_node: public rclcpp::Node
{
	public :
	 Multiple_subscriber_node();
	~Multiple_subscriber_ndoe();

	Msg_processor msg_inst;
	Skeleton *sk;
	Model_processor model_inst;

	private:
	void exception_handle( const ImageMsg::SharedPtr msgRGB, const ImageMsg::SharedPtr msgD, 
							const std_msgs::msg::Float32MultiArray::SharedPtr msgSKE, const std_msgs::msg::Float32Array::SharedPtr msgFLR);
	int image_show_double();

	cv_bridge::CvImageConstPtr cv_ptrRGB;
	cv_bridge::CvImageConstPtr cv_ptrD;

	std::shared_ptr<message_filters::Subscriber<sensor_msgs::msg::Image>> rgb_sub;
	std::shared_ptr<message_filters::Subscriber<sensor_msgs::msg::Image>>  depth_sub;
	std::shared_ptr<message_filters::Subscriber<Float32MultiArray>> skeleton_sub
	std::shared_ptr<message_filters::Subscriber<Float32MultiArray>> foor_sub;

	std::shared_ptr <message_filters::Synchronizer<approximate_sync_policy>> syncApproximate;
}; //end Multiple_subscriber_node

static std::string type2str(int type) {
	std::string r;
	uchar depth = type & CV_MAT_DEPTH_MASK;
	uchar chans = 1+ (type>> CV_CN_SHIFT);

	switch(depth){
	case CV_8U: r= "8U"; break;
	case CV_8S: r= "8S"; break;
	case CV_16U: r= "16U"; break;
	case CV_16S: r= "16S"; break;
	case CV_32S: r= "32S"; break;
	case CV_32F: r= "32F"; break;
	case CV_64F: r= "64F"; break;
	default: r="User"; break;
	}

	r+= "C";
	r+= ( chans+'0');

	return r;
} //end type2str

#endif