#include <opencv2/highgui/highgui.hpp>
#include<opencv2/imgproc/imgproc.hpp>

#include<iostream>
#include<math.h>

#include "model_processor.hpp"

static int frame_cnt_model = 0;

Model_processor::Model_processor(){
	get_camera_intrinsics(intri);
	depth_factor = 0.001;
}

Model_processor::~Model_processor(){
}

int Model_processor::proc( double &height, const double (&ground)[4], const float (&skeleton_data)[17][3], const cv::Mat &matD) {
	double point3d[3];
	float nose[2];
	int nose_index =0;

	int edge_x =2;
	int edge_y = 2;
	nose[0] = skeleton_data[nose_index][0];
	nose[1] = skeleton_data[nose_index][1];
	double depth = static_cast<double> (matD.at<ushort>(int(nose[1]), int(nose[0])));

	project2dto3d( point3d, nose, depth);

	std::cout<< "nose 3d coord :" ;
	for (int i=0; i<3; i++) {
		std::cout << point3dd[i] << " ";
	}
	std::cout << std::endl;

	//debug:save image
	float pixel_nose[2];
	project3dto2d(pixel_nose, point3d);
	std::cout << "nose 2d back_proj coord: ";
	for(int i=0; i<2; i++){
		std::cout << int(pixel_nose[i]) << " ";
	}
	std::cout << std::endl;

	float pixel_nose_onground[2];
	double des_point[3];
	point_on_plane(des_point, ground, point3d);
	project3dto2d( pixel_nose_ongound, des_point);
	std::cout << "nose onground 2d back_proj coord: " 
	for( int i=0; i<2; i++){
		std::cout<< int(pixel_nose_onground[i]) << " ";
	}
	std::cout << std::endl;

	cv::Mat tempMatD;
	double tmp_scale = 255/4000;
	matD.converTo(tempMatD. CV_8U, tmp_scale);
	cv::circle( tempMatD, cv::Point2i( int(pixel_nose[0]), int(pixel_nose[1])), 5, cv_Scalar(0,0,255), -1);
	cv::circle( tempMatD, cv::Point2i( int(pixel_nose_onground[0]), int(pixel_nose_onground[1])), 5, cv_Scalar(0,0,255), -1);

	height = ground[0] * point3d[0] + ground[1] * point3d[1] + ground[2] * point3d[2] + ground[3];
	height = height/ sqrt( ground[0]*ground[0] + ground[1] * ground[1] + ground[2] * ground[2]);
	std::cout << "height:" << height <<std::endl;

	double headtop_point[3];
	double length_extend = 0.17;
	float headtop_pixel[2];
	extend_3dlength(headtop_point, point3d, ground, length_extend, height);
	project3dto2d(headtop_pixel, headtop_point);
	//headtop 2d back-proj coord

	double height_ext = //headtop_point to ground distance 3d
	std::cout << "height_ext:" << height_ext << std::endl;

	return 0;
}// end proc()

Model_processor::project2dto3d(double point3d[3], const float point2d[2], const double depth){
	point3d[2] = depth * depth_factor;
	point3d[0] = (point2d[0] - intri.ppx) * point3d[2] / intri.fx;
	point3d[1] = (point2d[1] - intri.ppy) * point3d[2] / intri.fy;
}

Model_processor::point_on_plane(double des_point[3], const double ground[4] , const double src_point[3] ){
	double factor2 = ground[0] * ground[0]+ ground[1] * ground[1] + ground[2] * ground[2];
	double t = (ground[0] * src_point[0] + ground[1] * src_point[1] + ground[2] * src_point[2] +ground[3]) / factor2;
	des_point[0] = src_point[0] - ground[0] *t;
	des_point[1] = src_point[1] - ground[1] *t;
	des_point[2] = src_point[2] - ground[2] *t;
}

Model_processor::project3dto2d(float pixel[2], const double point[3]) {
	double x=point[0] / point[2];
	double y =point[1]/point[2];
	pixel[0] = x*intri.fx + intri.ppx;
	pixel[1] = y*intri.fy + intri.ppy;
}

Model_processor::extend_3dlength( double ext_point[3], const double src_point[3], const_double ground[4], double length_extend, double distance){
	double factor2 = ground[0] * ground[0]+ ground[1] * ground[1] + ground[2] * ground[2];
	double t = (ground[0] * src_point[0] + ground[1] * src_point[1] + ground[2] * src_point[2] +ground[3]) / factor2;
	des_point[3];
	des_point[0] = src_point[0] - ground[0] *t;
	des_point[1] = src_point[1] - ground[1] *t;
	des_point[2] = src_point[2] - ground[2] *t;
	for (int i=0; i<3; i++){
	ext_point[i] = src_point[i] + length_extend* (src_point[i] - des_point[i] )/distance;
	}
}//end extend3dlength()