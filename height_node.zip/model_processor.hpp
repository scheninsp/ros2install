#ifndef
#define
#include <opencv2/core/core.hpp>

typedef struct rs2_intrinsics_sc
{
	int width;
	int height;
	float ppx;
	float ppy; //principle point
	float fx;
	float fy;
	int model;
	float coeffs[5] //distortion coefficients
} rs2_intrinsics_sc;

static void get_camera_intrinsics(rs2_intrinsics_sc &intri){
	intri.width = 1280;
	intri.height=720;
	intri.ppx = 642.88293457;
	intri.ppy = 374.07019043;
	intri.fx = 922.820068359;
	intri.fy = 922.734558105;
	intri.model = 0;
	for (int i=0; i<5; i++){
		coeffs[i]=0;
	}
}

class Model_processor{
	public:
	rs2_intrinsics_sc intri;
	double depth_factor;

	Model_processor();
	~Model_processor();

	int proc( double &height, const double (&ground)[4], const float (&skeleton_data)[17][3], const cv::Mat &matD);

	private:
	project2dto3d(double point3d[3], const float point2d[2], const double depth);
	project3dto2d(float pixel[2], const double point[3]);
	point_on_plane(double des_point[3], const double ground[4] , const double src_point[3] );
	extend_3dlength( double ext_point[3], const double src_point[3], const_double ground[4], double length_extend, double distance);
};

#endif
